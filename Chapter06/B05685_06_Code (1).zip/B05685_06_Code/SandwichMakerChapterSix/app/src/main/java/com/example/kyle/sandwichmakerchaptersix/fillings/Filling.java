package com.example.kyle.sandwichmakerchaptersix.fillings;

/**
 * Created by kyle on 08/07/2016.
 */
public interface Filling {

    String getName();

    int getImage();

    int getKcal();

    boolean getVeg();

    int getPrice();
}
