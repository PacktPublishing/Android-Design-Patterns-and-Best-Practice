package com.example.kyle.layoutbuilder.builder;


public interface Shading {

    public int shade();

    public int background();
}
