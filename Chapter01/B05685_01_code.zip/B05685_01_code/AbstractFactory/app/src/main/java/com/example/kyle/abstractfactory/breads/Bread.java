package com.example.kyle.abstractfactory.breads;

/**
 * Created by kyle on 26/07/2016.
 */
public interface Bread {

    String name();

    String calories();
}
