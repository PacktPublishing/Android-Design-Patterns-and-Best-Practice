package com.example.kyle.abstractfactory.fillings;

/**
 * Created by kyle on 26/07/2016.
 */
public interface Filling {

    String name();

    String calories();
}
