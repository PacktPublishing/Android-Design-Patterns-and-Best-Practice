package com.example.kyle.builderpattern;

/**
 * Created by kyle on 27/07/2016.
 */
public interface Ingredient {

    String name();
    int calories();
}
