package com.mew.kyle.checkoutvisitor;

public interface Item {

    int accept(Visitor visitor);
}
