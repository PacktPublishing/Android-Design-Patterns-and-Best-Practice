package com.example.kyle.facadepattern.products;

/**
 * Created by kyle on 31/07/2016.
 */
public interface Product {
    int dispense();
}

