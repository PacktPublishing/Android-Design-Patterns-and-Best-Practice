package com.example.kyle.bridgepattern;

/**
 * Created by kyle on 30/07/2016.
 */
public interface SandwichInterface {

    void makeSandwich(String filling1, String filling2);
}
