package com.example.kyle.decoratorpattern;


public class Bagel extends Bread {

    public Bagel() {
        description = "Bagel";
        kcal = 250;
    }
}
