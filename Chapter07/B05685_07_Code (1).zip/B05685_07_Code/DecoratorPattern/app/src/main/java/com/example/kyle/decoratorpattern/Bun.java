package com.example.kyle.decoratorpattern;


public class Bun extends Bread {

    public Bun() {
        description = "Bun";
        kcal = 150;
    }
}
