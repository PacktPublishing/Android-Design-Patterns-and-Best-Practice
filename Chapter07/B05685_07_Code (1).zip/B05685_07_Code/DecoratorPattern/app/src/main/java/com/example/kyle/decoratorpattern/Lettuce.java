package com.example.kyle.decoratorpattern;


public class Lettuce extends Filling {

    public Lettuce() {
        description = "Lettuce";
        kcal = 1;
    }
}
