package com.example.kyle.simplesandwich;


public interface Ingredient {

    public String description();

    public int kcal();
}
