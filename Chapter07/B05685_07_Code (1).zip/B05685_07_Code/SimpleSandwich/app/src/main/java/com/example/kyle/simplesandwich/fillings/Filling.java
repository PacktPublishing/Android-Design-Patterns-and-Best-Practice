package com.example.kyle.simplesandwich.fillings;

import com.example.kyle.simplesandwich.Ingredient;


public abstract class Filling implements Ingredient {

    // EMPTY FOR NOW
}
