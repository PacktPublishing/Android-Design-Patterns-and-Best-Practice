package com.example.kyle.strategypattern.strategies;


public interface Strategy {

    String processPayment(float price);
}
